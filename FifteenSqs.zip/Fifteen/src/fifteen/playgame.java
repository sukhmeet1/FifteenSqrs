//this entire class is dedicated to the view aspect of the program
package fifteen;


public class playgame { //start of class
    
    //this creates the 2d array which all objects will use
    int [][] squares = new int [4][4];
    static int a, b;
        
    //this method spaces the boxes    
    public String format(int number){
        //this creates an instance variable called "number"
        if(number == 0){
            return " ";
        }
        return Integer.toString(number);
    }   
    
    

    //start - this is the constructor
    public void Fifteen(){
        
        int count = 0;
        //this is the formula to create the separate squares with spacing
        for (int a = 0; a < 4; a++){
            for (int b = 0; b < 4; b++){
                squares [a][b] = count;
                System.out.print(format(squares[a][b]) + "\t");
                count++;
}
            //this adds spacing
            System.out.println(" \n ");
                
    }
}//end - of constructor
    
    //this is meant to move the squares
    public void move (int number){
        if (number >= squares.length)
            return;
        int a, b;
        
    }
    //this will check for the number of neighbours(4, 3, or 2)
    public int findNeighbours(int [][] blank, int[][] array){
        int [][] numNeighbours = {{0}, {0}};
        if (blank > 3)      array[numNeighbours++] = blank - 4;
        if (blank < 12)     array[numNeighbours++] = blank + 4;
        if (blank % 4 != 0) array[numNeighbours++] = blank - 1;
        if (blank % 4 != 3) array[numNeighbours++] = blank + 1;
        return numNeighbours;
    }
    //this will display the numbers in a random order
    public void scramble(){
        int[][] neighbours = new int[4][4];
        int numNeighbours, temp, moveTo, blank = 15;
        for (int a = 0; a < 200; a++)
        for (int b = 0; b < 200; b++){
            numNeighbours = findNeighbours(blank, neighbours);
            moveTo = neighbours[rand.nextInt(numNeighbours)][rand.nextInt(numNeighbours)];
            temp = squares[moveTo][moveTo];
            squares[blank][blank] = squares[blank][blank];
            squares[blank][blank] = temp;
            blank = moveTo;
        }
    }
    
    
}// end of class
