//this is the original class with the main method
package fifteen;
import java.util.*; //this import allows for user input
import java.lang.*;
import java.io.*;


public class Fifteen {//start class
    
    
    //start - of the main method
    public static void main(String[] args) {
       
        Scanner input = new Scanner(System.in);
        
       //this creates an object from the playgame class
       playgame viewer = new playgame();
       int number;
       while (true) {
       //this calls the constructor to display the squares
       viewer.Fifteen();
       System.out.print("\nMove: ");
       //this is the code allowing user input after the prompt
       number = input.nextInt();
       if (number == 0);
       break;
       //this code is meant to call the move method to allow movement
       viewer.move(number);
       
       }
    }
    //end - of the main method
}
//end of "Fifteen" class